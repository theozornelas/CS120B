/*
 * sdeba001_lab03_excercise04_challenge.c
 * Read 8-bit input and swap upper and lower nibbles on output
 * Created: 4/8/2019 3:14:58 PM
 * Author : Sky DeBaun
 * Email: sdeba001@ucr.edu
 * Lab Section: 021
 * All content contained herein, excluding template or example code, is my original work
 */

#include <avr/io.h>

//MAIN------------------------------------------------------
int main(void)
{
	
	 //input---------------------
	 DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	 
	 //output--------------------
	 DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs
	 DDRC = 0xFF; PORTC = 0x00; // Configure port C's 8 pins as outputs
	 
	 //vars----------------------
	 unsigned char swapVar = 0x00;
	 unsigned char lowToHighNibble = 0x00;
	 unsigned char highToLowNibble = 0x00;	 
	 
    
    while (1) 
    {
		//get input--------------
		lowToHighNibble = PINA & 0x0F; //get low nibble
		highToLowNibble = PINA & 0xF0; //get high nibble		
		
		//swap prep--------------
		lowToHighNibble = lowToHighNibble << 4; //low nibble shifted to high position
		highToLowNibble = highToLowNibble >> 4; //high nibble shifted to low position
		
		//assign to swap var-----
		swapVar = (lowToHighNibble + highToLowNibble);//simple addition concatenates low and high nibbles
		
		//assign to output-------
		PORTB = highToLowNibble;
		PORTC = lowToHighNibble;		
		
    }//end while--//
	
}//end main---///

