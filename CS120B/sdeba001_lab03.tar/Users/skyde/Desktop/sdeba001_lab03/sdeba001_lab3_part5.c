/*
 * sdeba001_lab03_excercise05_challenge.c
 * Car passenger seat airbag sensor
 * Created: 4/9/2019 6:28:00 PM
 * Author : Sky DeBaun
 * Email: sdeba001@ucr.edu
 * Lab Section: 021
 * All content contained herein, excluding template or example code, is my original work
 */

#include <avr/io.h>

//MAIN--------------------------------------------------
int main(void)
{
    //input---------------------
    DDRD = 0x00; PORTD = 0xFF; // Configure port D's 8 pins as inputs
    
    //output--------------------
    DDRB = 0xFE; PORTB = 0x01; // Configure port B ->  B1 - B7(OUTPUT) and B0(INPUT)
    
    //vars----------------------
	unsigned short passengerWeight = 0x00;
	unsigned char airbagIndicator = 0x00;	
	
	
    while (1) 
    {		
		//get PINA's inputs-----
		passengerWeight = PIND;//represents 8 upper bits (of 9 bit input)
		
		//get 9 bits from seat sensor
		passengerWeight = passengerWeight << 1; //shift left (make room for B0 additional input)
		passengerWeight = passengerWeight + (PINB & 0X01); //PINB0 bit added to PINA inputs
		
		/*
		AIRBAG WEIGHT SCALE------
		00-05 -> no passenger
		06-69 -> airbag disabled
		70&up -> airbag enabled
		*/
		
		//no passenger-----------
		if(passengerWeight <= 5)
		{
			airbagIndicator = 0x00;
		}
		//airbag disabled--------
		else if(passengerWeight > 5 && passengerWeight < 70)
		{
			airbagIndicator = 0x04;//set PB2 (airbag disabled)
		}
		//airbag enabled---------
		else
		{
			airbagIndicator = 0x02;//set PB1 (airbag enabled)
		}
		
		//output-----------------
		PORTB = airbagIndicator;
		
		
    }//end while--//	
	
}//end main---///

