/*
 * sdeba001_lab03_excercise01.c
 * Count input bits on A, then output on C
 * Created: 4/8/2019 1:50:18 PM
 * Author : Sky DeBaun
 * Email: sdeba001@ucr.edu
 * Lab Section: 021
 * All content contained herein, excluding template or example code, is my original work
 */

#include <avr/io.h>

//MAIN---------------------------------------------------
int main(void)
{
	//constants-----------------
	const unsigned char NUM_BITS = 8;
	
    //input---------------------
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs	
	
	//output--------------------
	DDRC = 0xFF; PORTC = 0x00; // Configure port C's 8 pins as outputs,
	
	//tmp vars-----------------
	unsigned char inputBits = 0x00;
	unsigned char count = 0x00;
	
	
    while (1) 
    {
		inputBits = PINA;
		
		//check for 1 in LSB, then shift right for next space
		for(unsigned char i = 0; i < NUM_BITS; ++ i )
		{
			if((inputBits & 0x01) == 0x01) //looking at right most bit only!
			{
				++count;//decrement counter if car present
			}
			//shift right to facilitate right most checks (only)
			inputBits = inputBits >> 1;
			
		}//end for i--//
		
		PORTC = count;
		count = 0x00;//clear counter for next while loop
		
    }//end while--//
	
}//end main---///

