/*
 * sdeba001_lab03_excercise02.c
 * Car fuel level sensor
 * Created: 4/8/2019 2:23:29 PM
 * Author : Sky DeBaun
 * Email: sdeba001@ucr.edu
 * Lab Section: 021
 * All content contained herein, excluding template or example code, is my original work
 */
#include <avr/io.h>

//MAIN-----------------------------------------------------
int main(void)
{
     //input---------------------> fuel level sensor
     DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
     
     //output--------------------> fuel level gauge
     DDRC = 0xFF; PORTC = 0x00; // Configure port C's 8 pins as outputs,
     
	 //vars----------------------
	 unsigned char fuelLevel = 0x00;
	 
	 
    while (1) 
    {
		fuelLevel = PINA & 0x0F;//0 = empty, 15 = full (checking lower nibble only)
		PORTC = 0x00;//reset output
		
		/*
		FUEL LEVEL TO GAUGE GUIDE
		00    -> EMPTY
		01-02 -> LED 5 (PC5) -> 0x20
		03-04 -> LED 5, 4 (PC5, PC4) -> 0x30
		05-06 -> LED 5, 4, 3 (PC5, PC4, PC3) -> 0x38
		07-09 -> LED 5, 4, 3, 2 (PC5, PC4, PC3, PC2) -> 0x3C
		10-12 -> LED 5, 4, 3, 2, 1 (PC5, PC4, PC3, PC2, PC1) -> 0x3E
		13-15 -> LED 5, 4, 3, 2, 1, 0 (PC5, PC4, PC3, PC2, PC1, PC0) -> 0x3F
		
		NOTE: Low Fuel indicator on for levels 0-4
		LOW FUEL -> LED 6
		
		*/
		
		//set indicator lights--------
		switch(fuelLevel)
		{
			case 0: break;
			
			case 1:
			case 2: PORTC = 0x20; break;
			
			case 3:
			case 4: PORTC = 0x30; break;
			
			case 5:
			case 6: PORTC = 0x38;
			
			case 7:
			case 8:
			case 9: PORTC = 0x3C; break;
			
			case 10:
			case 11:
			case 12: PORTC = 0x3E; break;
			
			case 13:
			case 14:
			case 15: PORTC = 0x3F; break;
			
			default: PORTC = 0x3F; break;
		}//end switch--//
		
		//low fuel level indicator
		if(fuelLevel <= 4)
		{
			PORTC = PORTC | 0x40;
			
		}

		
    }//end while--//
	
}//end main---///

