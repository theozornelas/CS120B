/*
 * sdeba001_lab03_excercise03.c
 * Car fuel level + seatbelt 
 * Created: 4/8/2019 3:16:40 PM
 * Author : Sky DeBaun
 * Email: sdeba001@ucr.edu
 * Lab Section: 021
 * All content contained herein, excluding template or example code, is my original work
 */

#include <avr/io.h>

//MAIN-----------------------------------------------------
int main(void)
{
     //input---------------------> fuel level sensor
     DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
     
     //output--------------------> fuel level gauge
     DDRC = 0xFF; PORTC = 0x00; // Configure port C's 8 pins as outputs,
     
	 //vars----------------------
	 unsigned char sensorInput = 0x00;
	 
	 
    while (1) 
    {
		//get fuel level------------------------------------
		sensorInput = PINA ;//0 = empty, 15 = full (checking lower nibble only)
		PORTC = 0x00;//reset
		/*
		FUEL LEVEL TO GAUGE GUIDE
		-------------------------
		00    -> EMPTY
		01-02 -> LED 5 (PC5) -> 0x20
		03-04 -> LED 5, 4 (PC5, PC4) -> 0x30
		05-06 -> LED 5, 4, 3 (PC5, PC4, PC3) -> 0x38
		07-09 -> LED 5, 4, 3, 2 (PC5, PC4, PC3, PC2) -> 0x3C
		10-12 -> LED 5, 4, 3, 2, 1 (PC5, PC4, PC3, PC2, PC1) -> 0x3E
		13-15 -> LED 5, 4, 3, 2, 1, 0 (PC5, PC4, PC3, PC2, PC1, PC0) -> 0x3F
		
		NOTE: Low Fuel indicator on for levels 0-4
		LOW FUEL -> LED 6		
		
		*/		
		
		//set indicator lights--------
		switch(sensorInput & 0x0F)//masking sensorInput for lower nibble only
		{
			case 0: break;
			
			case 1:
			case 2: PORTC = 0x20; break;
			
			case 3:
			case 4: PORTC = 0x30; break;
			
			case 5:
			case 6: PORTC = 0x38;
			
			case 7:
			case 8:
			case 9: PORTC = 0x3C; break;
			
			case 10:
			case 11:
			case 12: PORTC = 0x3E; break;
			
			case 13:
			case 14:
			case 15: PORTC = 0x3F; break;
			
			default: PORTC = 0x3F; break;
		}//end switch--//
		
		//low fuel level indicator
		if((sensorInput & 0x0F) <= 4)//masked input checks lower nibble only
		{
			PORTC = PORTC | 0x40;			
		}
		
		
		/*
		
		CHECK FOR KEY, DRIVER SEATED, NOT SEATBELT
		-------------------------------------
		
		KEY IN IGNITION
		-------------------------
		PINA4 = 1
		
		DRIVER SEATED
		-------------------------
		PINA5 = 1
		
		SEATBELT ON
		-------------------------
		PINA6 = 1
		
		*/
		
		//if key and driver and NOT seatbelt -> set seatbelt icon		
		if((sensorInput & 0xF0) == 0x30)//masked input check high nibble only
		{
			PORTC = (PORTC |0b10000000);//set bit 7		
		}
		
		
    }//end while--//
	
}//end main---///